# PPE detection > 2023-10-14 1:40pm
https://universe.roboflow.com/ppe-detection-9yxff/ppe-detection-yj4rr

Provided by a Roboflow user
License: CC BY 4.0

